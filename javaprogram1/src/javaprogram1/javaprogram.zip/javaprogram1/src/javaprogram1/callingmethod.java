package javaprogram1;

public class callingmethod {
		 
	    static void myMethod() {
	        System.out.println("hello");
	    }
	 
	    public static void main(String[] args) {
	        myMethod();
	    }
	}
