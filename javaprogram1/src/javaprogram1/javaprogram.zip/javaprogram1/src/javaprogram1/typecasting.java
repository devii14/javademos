package javaprogram1;

public class typecasting {
	public static void main(String [] args) {
		byte a=10;
		short b = a;
		System.out.println(a);
		System.out.println(b);
		short c = 10;
		byte d=(byte)c;
		System.out.println(c);
		System.out.println(d);
	}

}
