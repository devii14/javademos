package javaprogram1;
import java.util.ArrayList;
	class collection {
	    public static void main(String[] args){
	        ArrayList<String> animals = new ArrayList<>();
	        animals.add("Dog");
	        animals.add("Cat");
	        animals.add("Horse");

	        System.out.println("ArrayList: " + animals);
	    }
	}
